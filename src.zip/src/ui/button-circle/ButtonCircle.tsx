import clsx from 'clsx';
import styles from './ButtonCircle.module.scss';
import PlusIcon from '@/assets/img/icon-l/plus-lg.svg?react';

type CircleButtonVariant = 'purple' | 'gray' | 'green';

interface CircleButtonProps {
    variant?: CircleButtonVariant;
    onClick?: () => void;
}

export default function CircleButton({
                                         variant = 'purple',
                                         onClick,
                                     }: CircleButtonProps) {
    return (
        <button
            className={clsx(styles.button, {
                [styles.purple]: variant === 'purple',
                [styles.gray]: variant === 'gray',
                [styles.green]: variant === 'green',
            })}
            onClick={onClick}
            aria-label="Создать"
        >
            <PlusIcon className={styles.icon}/>
        </button>
    );
}
